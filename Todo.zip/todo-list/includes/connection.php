<?php

/*Php documentation.We do in this order because of the local host documention. First we have local host then our username, password which is root again then our data base name which is task.
*/
	$dbHost = 'localhost:3306';
	$dbName = 'task';
	$dbUsername = 'root';
	$dbPassword = '';
	
	session_start();

	$_SESSION['user_id'] = 1;

	$db = new PDO('mysql:host=' . $dbHost . ';dbname=' . $dbName . '', $dbUsername, $dbPassword);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

	if(!isset($_SESSION['user_id'])) {

		die('You\'re not signed in!');

	}

?>