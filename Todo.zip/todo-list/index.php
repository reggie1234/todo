
<?php

	require_once 'connect.php';

	$itemsQuery = $db->prepare("
		SELECT id, task
		FROM items
		WHERE user = :user
	");

	$itemsQuery->execute([
		'user' => $_SESSION['user_id']
	]);

	$items = $itemsQuery->rowCount() ? $itemsQuery : [];

?>
